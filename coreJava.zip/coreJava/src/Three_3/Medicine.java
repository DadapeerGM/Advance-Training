package Three_3;

public class Medicine {
	public void displayLabel(){
		System.out.println("Company : Globex Pharma");
		System.out.println("Address : Bangalore");}}
		class Tablet extends Medicine{
		 
		
}
