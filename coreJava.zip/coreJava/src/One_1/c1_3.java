package One_1;

public class c1_3 {
	String c1_3_tittle;
	double c1_3_price;
	
	public c1_3(String c1_3_tittle, double c1_3_price)
	{
		this.c1_3_tittle= c1_3_tittle;
		this.c1_3_price = c1_3_price;
	}
	
	public String getc1_3_tittle() {
		return c1_3_tittle;
	}
	public void setc1_3_tittle(String c1_3_tittle) {
		this.c1_3_tittle = c1_3_tittle;
	}
	public double getc1_3_price() {
		return c1_3_price;
	}
	public void setc1_3_price(double c1_3_price) {
		this.c1_3_price = c1_3_price;
	}
	
	 public void display(){
	      System.out.println("c1_3_title: "+this.c1_3_tittle);
	      System.out.println("c1_3_price: "+this.c1_3_price);
	      
	   }

}
