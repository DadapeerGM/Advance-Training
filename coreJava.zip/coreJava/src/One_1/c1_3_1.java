package One_1;

public class c1_3_1 {public void createc1_3s() {
	c1_3 bk[] = new c1_3[2];		 
    bk[0] = new c1_3("Java Programing ", 350.50);
    bk[1] = new c1_3("Let Us C", 200.00);
    for(int i = 0; i<bk.length; i++) {
	         bk[i].display();
	         System.out.println(" ");
    }
  
    }

public void showc1_3s() {
	  	createc1_3s();
	
}
public static void main(String args[])  {
  c1_3_1 c1 = new c1_3_1();  
	c1.showc1_3s();
 
    }

}
